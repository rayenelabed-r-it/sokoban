# ============================================================
#  menu.py  –  Écran de sélection de difficulté et de niveau
# ============================================================
import pygame
from build_game import DIFFICULTY_LEVELS

BG_COLOR     = (15, 15, 35)
TITLE_COLOR  = (255, 220, 80)
NORMAL_COLOR = (200, 200, 220)
SELECT_COLOR = (80, 200, 120)
HOVER_COLOR  = (255, 160, 40)
BOX_COLOR    = (30, 30, 60)
BOX_BORDER   = (80, 80, 140)


class MenuButton:
    def __init__(self, rect, text, value):
        self.rect  = pygame.Rect(rect)
        self.text  = text
        self.value = value

    def draw(self, surface, font, selected=False, hovered=False):
        color = SELECT_COLOR if selected else (HOVER_COLOR if hovered else BOX_COLOR)
        pygame.draw.rect(surface, color, self.rect, border_radius=8)
        pygame.draw.rect(surface, BOX_BORDER, self.rect, 2, border_radius=8)
        txt_color = (20, 20, 20) if selected or hovered else NORMAL_COLOR
        label = font.render(self.text, True, txt_color)
        surface.blit(label, label.get_rect(center=self.rect.center))


def run_menu(screen):
    """
    Affiche le menu de sélection.
    Retourne (difficulty_name: str, level_path: str) ou None si quitter.
    """
    pygame.display.set_caption("Sokoban – Menu")
    font_title  = pygame.font.SysFont("Arial", 42, bold=True)
    font_sub    = pygame.font.SysFont("Arial", 28, bold=True)
    font_btn    = pygame.font.SysFont("Arial", 22)
    font_hint   = pygame.font.SysFont("Arial", 18)

    difficulties = list(DIFFICULTY_LEVELS.keys())
    sel_diff = 0      # index de difficulté sélectionnée
    sel_lvl  = 0      # index de niveau sélectionné
    mouse_pos = (0, 0)

    clock = pygame.time.Clock()

    while True:
        W, H = screen.get_width(), screen.get_height()
        screen.fill(BG_COLOR)

        # Titre
        t = font_title.render("🎮  SOKOBAN", True, TITLE_COLOR)
        screen.blit(t, t.get_rect(center=(W // 2, 70)))

        sub = font_sub.render("Choisissez une difficulté", True, NORMAL_COLOR)
        screen.blit(sub, sub.get_rect(center=(W // 2, 130)))

        # Boutons de difficulté
        diff_buttons = []
        btn_w, btn_h = 160, 48
        total_w = len(difficulties) * btn_w + (len(difficulties) - 1) * 20
        sx = (W - total_w) // 2
        for i, diff in enumerate(difficulties):
            rect = (sx + i * (btn_w + 20), 165, btn_w, btn_h)
            btn = MenuButton(rect, diff, diff)
            hovered = btn.rect.collidepoint(mouse_pos)
            btn.draw(screen, font_btn, selected=(i == sel_diff), hovered=hovered)
            diff_buttons.append(btn)

        # Sous-titre niveaux
        sub2 = font_sub.render("Choisissez un niveau", True, NORMAL_COLOR)
        screen.blit(sub2, sub2.get_rect(center=(W // 2, 265)))

        # Boutons de niveau
        levels = DIFFICULTY_LEVELS[difficulties[sel_diff]]
        lvl_buttons = []
        btn_w2 = 120
        total_w2 = len(levels) * btn_w2 + (len(levels) - 1) * 20
        sx2 = (W - total_w2) // 2
        for j, path in enumerate(levels):
            name = f"Niveau {j + 1}"
            rect = (sx2 + j * (btn_w2 + 20), 295, btn_w2, btn_h)
            btn = MenuButton(rect, name, path)
            hovered = btn.rect.collidepoint(mouse_pos)
            btn.draw(screen, font_btn, selected=(j == sel_lvl), hovered=hovered)
            lvl_buttons.append(btn)

        # Bouton Jouer
        play_rect = pygame.Rect(W // 2 - 100, 390, 200, 56)
        pygame.draw.rect(screen, (50, 180, 80), play_rect, border_radius=10)
        pygame.draw.rect(screen, (20, 120, 40), play_rect, 2, border_radius=10)
        play_txt = font_sub.render("▶  JOUER", True, (255, 255, 255))
        screen.blit(play_txt, play_txt.get_rect(center=play_rect.center))

        # Hint
        hint = font_hint.render("Touches : Flèches = déplacer  |  A = solver IA  |  R = reset  |  Q = quitter", True, (130, 130, 160))
        screen.blit(hint, hint.get_rect(center=(W // 2, H - 30)))

        pygame.display.flip()
        clock.tick(60)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return None
            if event.type == pygame.KEYDOWN and event.key == pygame.K_q:
                return None
            if event.type == pygame.MOUSEMOTION:
                mouse_pos = event.pos
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                # Difficulté
                for i, btn in enumerate(diff_buttons):
                    if btn.rect.collidepoint(event.pos):
                        sel_diff = i
                        sel_lvl  = 0
                # Niveau
                for j, btn in enumerate(lvl_buttons):
                    if btn.rect.collidepoint(event.pos):
                        sel_lvl = j
                # Jouer
                if play_rect.collidepoint(event.pos):
                    return difficulties[sel_diff], levels[sel_lvl]
